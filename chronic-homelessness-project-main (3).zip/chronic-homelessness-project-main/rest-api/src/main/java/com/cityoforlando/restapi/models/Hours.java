package com.cityoforlando.restapi.models;

import lombok.Data;

@Data
public class Hours {
    private String sunday;
    private String monday;
    private String tuesday;
    private String wednesday;
    private String thursday;
    private String friday;
    private String saturday;
}
