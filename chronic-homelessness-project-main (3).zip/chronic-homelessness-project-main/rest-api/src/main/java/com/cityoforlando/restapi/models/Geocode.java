package com.cityoforlando.restapi.models;

import lombok.Data;

@Data
public class Geocode {
    private Float lat;
    private Float lng;
}
