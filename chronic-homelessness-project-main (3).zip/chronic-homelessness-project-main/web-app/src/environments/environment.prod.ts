export const environment = {
  production: true,
  google_maps_api_key: '' //enter your Google Maps API key here
};
