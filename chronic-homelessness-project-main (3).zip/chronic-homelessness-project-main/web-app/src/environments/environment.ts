export const environment = {
  production: false,
  google_maps_api_key: '' //enter your Google Maps API key here
};
