import { Users } from "./models"

export const UsersList: Array<Users> = [
  {
    "id": "afkmae;namd",
    "username": "Lola23",
    "firstname": "Lilliam",
    "lastname": "Castro",
    "password": "project2",
    "dateCreated": new Date("2021-09-03T00:00:00.000+00:00"),
    "dateUpdated": new Date("2021-12-05T00:00:00.000+00:00"),
    }
]
